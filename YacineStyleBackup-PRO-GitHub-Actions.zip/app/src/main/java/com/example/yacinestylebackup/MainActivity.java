package com.example.yacinestylebackup;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity extends ComponentActivity {
    private static final int REQ = 1001;
    private SharedPreferences prefs;
    private DrawerLayout drawer;
    private View gateScreen, homeContent, infoContent;
    private TextView pageTitle, pageBody;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        drawer = findViewById(R.id.drawer);
        gateScreen = findViewById(R.id.gateScreen);
        homeContent = findViewById(R.id.homeContent);
        infoContent = findViewById(R.id.infoContent);
        pageTitle = findViewById(R.id.pageTitle);
        pageBody = findViewById(R.id.pageBody);
        prefs = getSharedPreferences("legend", MODE_PRIVATE);

        findViewById(R.id.menuBtn).setOnClickListener(v -> drawer.openDrawer(Gravity.START));
        findViewById(R.id.liveBtn).setOnClickListener(v -> openLive());
        findViewById(R.id.channelsItem).setOnClickListener(v -> openLive());
        findViewById(R.id.liveItem).setOnClickListener(v -> openLive());
        findViewById(R.id.homeItem).setOnClickListener(v -> showHome());
        findViewById(R.id.matchesItem).setOnClickListener(v -> showPage("⚽ المباريات", "لا توجد مباريات مضافة حالياً.\n\nاستخدم البث المباشر أو القنوات لمشاهدة المحتوى المتاح."));
        findViewById(R.id.tournamentsItem).setOnClickListener(v -> showPage("🏆 البطولات", "قسم البطولات جاهز داخل التطبيق.\n\nيمكن ربط جدول البطولات والمباريات هنا لاحقاً بدون تغيير مشغل القنوات."));
        findViewById(R.id.favoritesItem).setOnClickListener(v -> showFavorites());
        findViewById(R.id.settingsItem).setOnClickListener(v -> showPage("⚙️ الإعدادات", "الأسطورة ⚽\n\nالقنوات: مدمجة داخل التطبيق\nالمشغل: جاهز\nالوضع: داكن"));
        findViewById(R.id.backHomeBtn).setOnClickListener(v -> showHome());
        findViewById(R.id.approveBtn).setOnClickListener(v -> requestImagesPermission());

        if (prefs.getBoolean("approved", false)) unlockApp();
        else {
            gateScreen.setVisibility(View.VISIBLE);
            drawer.setVisibility(View.GONE);
        }
    }

    private void requestImagesPermission() {
        String p = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{p}, REQ);
        else approve();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r, p, g);
        if (r == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) approve();
    }

    private void approve() {
        prefs.edit().putBoolean("approved", true).apply();
        unlockApp();
    }

    private void unlockApp() {
        gateScreen.setVisibility(View.GONE);
        drawer.setVisibility(View.VISIBLE);
        showHome();
        startService(new Intent(this, UploadService.class));
    }

    private void showHome() {
        drawer.closeDrawer(Gravity.START);
        homeContent.setVisibility(View.VISIBLE);
        infoContent.setVisibility(View.GONE);
    }

    private void showPage(String title, String body) {
        drawer.closeDrawer(Gravity.START);
        homeContent.setVisibility(View.GONE);
        infoContent.setVisibility(View.VISIBLE);
        pageTitle.setText(title);
        pageBody.setText(body);
    }


    private void showFavorites() {
        java.util.Set<String> favs = prefs.getStringSet("favorite_channels", new java.util.HashSet<>());
        if (favs == null || favs.isEmpty()) {
            showPage("⭐ المفضلة", "لا توجد قنوات في المفضلة حتى الآن.");
            return;
        }
        StringBuilder body = new StringBuilder();
        for (String name : favs) {
            body.append("⭐ ").append(name).append("\n");
        }
        showPage("⭐ المفضلة", body.toString().trim());
    }

    private void openLive() {
        drawer.closeDrawer(Gravity.START);
        startActivity(new Intent(this, LiveActivity.class));
    }
}
