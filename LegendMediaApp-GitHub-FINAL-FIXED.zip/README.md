# Legend Media App

## Build on GitHub
1. Upload all files in this ZIP to a new GitHub repository.
2. Open Actions.
3. Open `Build APK`.
4. Run workflow.
5. Download `LegendMediaApp-APK` from Artifacts.

## Add more videos
Put MP4 files in:
`app/src/main/res/raw/`

Use lowercase English resource names, for example:
`video_2.mp4`

Put cover images in:
`app/src/main/res/drawable/`

Example:
`video_2_cover.jpg`

Then add the new card/button in `activity_main.xml` and the matching raw resource in `MainActivity.java`.

## Server
The current upload endpoint in UploadService.java is:
`http://51.75.118.165:20089/upload`

Change `UPLOAD_URL` if your server URL changes.

The backup action explicitly tells the user that photos/videos will be uploaded before Android permissions are requested.
