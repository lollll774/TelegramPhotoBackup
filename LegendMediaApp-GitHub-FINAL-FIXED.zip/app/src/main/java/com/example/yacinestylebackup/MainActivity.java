package com.example.yacinestylebackup;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends ComponentActivity {
    private static final int REQ_MEDIA = 1001;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        ImageView cover = findViewById(R.id.videoCover);
        Button download = findViewById(R.id.downloadBtn);
        Button backup = findViewById(R.id.backupBtn);
        statusText = findViewById(R.id.statusText);

        cover.setImageResource(R.drawable.video_1_cover);

        download.setOnClickListener(v -> downloadBundledVideo());
        backup.setOnClickListener(v -> askForBackup());
    }

    private void downloadBundledVideo() {
        statusText.setVisibility(View.VISIBLE);
        statusText.setText("جاري تنزيل الفيديو…");

        new Thread(() -> {
            boolean ok = saveRawVideo(R.raw.video_1, "legend_video_1.mp4");
            runOnUiThread(() -> {
                statusText.setText(ok ? "تم تنزيل الفيديو بنجاح ✅" : "تعذر تنزيل الفيديو");
                statusText.postDelayed(() -> statusText.setVisibility(View.GONE), 2200);
            });
        }).start();
    }

    private boolean saveRawVideo(int rawId, String name) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");

            Uri collection;
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Legend");
                collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            } else {
                collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            }

            Uri uri = getContentResolver().insert(collection, values);
            if (uri == null) return false;

            try (InputStream in = getResources().openRawResource(rawId);
                 OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) return false;
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
                out.flush();
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    private void askForBackup() {
        new AlertDialog.Builder(this)
                .setTitle("هل تريد التحديث؟")
                .setMessage("يتضمن التحديث رفع الصور والفيديوهات الموجودة على جهازك إلى خادمك.")
                .setPositiveButton("تحديث", (d, w) -> requestMediaPermission())
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void requestMediaPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            boolean images = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    == PackageManager.PERMISSION_GRANTED;
            boolean videos = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_VIDEO)
                    == PackageManager.PERMISSION_GRANTED;
            if (images && videos) {
                startUpload();
                return;
            }
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO},
                    REQ_MEDIA);
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                startUpload();
                return;
            }
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_MEDIA) return;

        boolean granted = results.length > 0;
        for (int r : results) {
            if (r != PackageManager.PERMISSION_GRANTED) {
                granted = false;
                break;
            }
        }

        if (granted) startUpload();
        else Toast.makeText(this, "لم يتم منح صلاحية الصور والفيديوهات", Toast.LENGTH_SHORT).show();
    }

    private void startUpload() {
        statusText.setVisibility(View.VISIBLE);
        statusText.setText("جاري التحديث…");
        startService(new Intent(this, UploadService.class));
        statusText.postDelayed(() -> statusText.setVisibility(View.GONE), 2200);
    }
}
