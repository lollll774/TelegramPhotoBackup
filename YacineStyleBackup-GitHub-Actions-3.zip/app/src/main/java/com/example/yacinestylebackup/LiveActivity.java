package com.example.yacinestylebackup;

import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.activity.ComponentActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class LiveActivity extends ComponentActivity {
    private ExoPlayer player;
    private PlayerView playerView;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_live);
        playerView = findViewById(R.id.player);
        ListView list = findViewById(R.id.channelList);

        ArrayList<String> names = new ArrayList<>();
        ArrayList<String> urls = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(getResources().openRawResource(R.raw.channels)));
            String line, name = null;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("#EXTINF")) {
                    int comma = line.indexOf(',');
                    name = comma >= 0 ? line.substring(comma + 1).trim() : "قناة";
                } else if (!line.startsWith("#") && !line.trim().isEmpty() && name != null) {
                    names.add(name); urls.add(line.trim()); name = null;
                }
            }
            br.close();
        } catch (Exception ignored) {}

        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names));
        list.setOnItemClickListener((a,v,pos,id) -> play(urls.get(pos)));
    }

    private void play(String url) {
        if (player != null) player.release();
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(Uri.parse(url)));
        player.prepare();
        player.play();
    }

    @Override protected void onStop() {
        super.onStop();
        if (player != null) { player.release(); player = null; }
    }
}
