package com.example.yacinestylebackup;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.ContentObserver;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.MediaStore;

public class UploadService extends Service {
    private ContentObserver observer;

    @Override public void onCreate() {
        super.onCreate();
        // Placeholder hook for the server upload worker.
        // The server URL is intentionally kept as a single non-secret setting.
        observer = new ContentObserver(new Handler()) {
            @Override public void onChange(boolean selfChange, Uri uri) {
                // Queue the upload worker here.
            }
        };
        ContentResolver cr = getContentResolver();
        cr.registerContentObserver(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true, observer);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (observer != null) getContentResolver().unregisterContentObserver(observer);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
