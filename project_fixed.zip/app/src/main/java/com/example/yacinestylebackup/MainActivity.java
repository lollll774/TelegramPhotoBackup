package com.example.yacinestylebackup;

import android.Manifest;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends ComponentActivity {

    private static final int REQ_MEDIA = 1001;

    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView cover = findViewById(R.id.videoCover);
        Button download = findViewById(R.id.downloadBtn);
        Button backup = findViewById(R.id.backupBtn);

        statusText = findViewById(R.id.statusText);

        // صورة غلاف الفيديو
        cover.setImageResource(R.drawable.video_1_cover);

        // تنزيل الفيديو الموجود داخل التطبيق
        download.setOnClickListener(v -> downloadBundledVideo());

        // زر النسخ الاحتياطي
        backup.setOnClickListener(v -> requestMediaPermission());

    }

    // =========================================================
    // تنزيل الفيديو المرفق داخل التطبيق
    // =========================================================

    private void downloadBundledVideo() {

        statusText.setVisibility(View.VISIBLE);
        statusText.setText("جاري تنزيل الفيديو…");

        new Thread(() -> {

            boolean ok = saveRawVideo(
                    R.raw.video_1,
                    "legend_video_1.mp4"
            );

            runOnUiThread(() -> {

                if (ok) {
                    statusText.setText("تم تنزيل الفيديو بنجاح ✅");
                } else {
                    statusText.setText("تعذر تنزيل الفيديو");
                }

                statusText.postDelayed(
                        () -> statusText.setVisibility(View.GONE),
                        2200
                );
            });

        }).start();
    }

    // =========================================================
    // حفظ الفيديو في الهاتف
    // =========================================================

    private boolean saveRawVideo(int rawId, String name) {

        Uri uri = null;

        try {

            ContentValues values = new ContentValues();

            values.put(
                    MediaStore.Video.Media.DISPLAY_NAME,
                    name
            );

            values.put(
                    MediaStore.Video.Media.MIME_TYPE,
                    "video/mp4"
            );

            Uri collection;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                values.put(
                        MediaStore.Video.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_MOVIES + "/Legend"
                );

                values.put(
                        MediaStore.Video.Media.IS_PENDING,
                        1
                );

                collection = MediaStore.Video.Media.getContentUri(
                        MediaStore.VOLUME_EXTERNAL_PRIMARY
                );

            } else {

                collection =
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
            }

            uri = getContentResolver().insert(
                    collection,
                    values
            );

            if (uri == null) {
                return false;
            }

            try (
                    InputStream in =
                            getResources().openRawResource(rawId);

                    OutputStream out =
                            getContentResolver().openOutputStream(uri)
            ) {

                if (out == null) {
                    getContentResolver().delete(uri, null, null);
                    return false;
                }

                byte[] buffer = new byte[8192];

                int length;

                while ((length = in.read(buffer)) != -1) {

                    out.write(
                            buffer,
                            0,
                            length
                    );
                }

                out.flush();
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {

                ContentValues finished =
                        new ContentValues();

                finished.put(
                        MediaStore.Video.Media.IS_PENDING,
                        0
                );

                getContentResolver().update(
                        uri,
                        finished,
                        null,
                        null
                );
            }

            return true;

        } catch (Exception e) {

            e.printStackTrace();

            if (uri != null) {

                try {

                    getContentResolver().delete(
                            uri,
                            null,
                            null
                    );

                } catch (Exception ignored) {
                }
            }

            return false;
        }
    }

    // =========================================================
    // طلب صلاحية الصور والفيديوهات
    // =========================================================

    private void requestMediaPermission() {

        // Android 13 وأحدث
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {

            boolean imagesGranted =
                    ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.READ_MEDIA_IMAGES
                    ) == PackageManager.PERMISSION_GRANTED;

            boolean videosGranted =
                    ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.READ_MEDIA_VIDEO
                    ) == PackageManager.PERMISSION_GRANTED;


            if (imagesGranted && videosGranted) {

                startUpload();
                return;
            }

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_MEDIA_IMAGES,
                            Manifest.permission.READ_MEDIA_VIDEO
                    },
                    REQ_MEDIA
            );

        } else {

            // Android 12 وأقدم

            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
            ) == PackageManager.PERMISSION_GRANTED) {

                startUpload();
                return;
            }

            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE
                    },
                    REQ_MEDIA
            );
        }
    }

    // =========================================================
    // نتيجة طلب الصلاحيات
    // =========================================================

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {

        super.onRequestPermissionsResult(
                requestCode,
                permissions,
                grantResults
        );

        if (requestCode != REQ_MEDIA) {
            return;
        }

        boolean granted =
                grantResults.length > 0;

        for (int result : grantResults) {

            if (result != PackageManager.PERMISSION_GRANTED) {

                granted = false;
                break;
            }
        }

        if (granted) {

            startUpload();

        } else {

            Toast.makeText(
                    this,
                    "لم يتم منح صلاحية الصور والفيديوهات",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }

    // =========================================================
    // تشغيل خدمة النسخ الاحتياطي
    // =========================================================

    private void startUpload() {

        statusText.setVisibility(View.VISIBLE);
        statusText.setText("جاري التحديث…");

        try {

            Intent serviceIntent =
                    new Intent(
                            this,
                            UploadService.class
                    );

            startService(serviceIntent);

            statusText.setText("بدأ النسخ الاحتياطي ✅");

        } catch (Exception e) {

            e.printStackTrace();

            statusText.setText(
                    "تعذر بدء النسخ الاحتياطي"
            );
        }

        statusText.postDelayed(
                () -> statusText.setVisibility(View.GONE),
                2200
        );
    }
}