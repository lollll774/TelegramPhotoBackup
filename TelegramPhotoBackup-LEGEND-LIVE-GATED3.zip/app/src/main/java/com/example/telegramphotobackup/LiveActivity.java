package com.example.telegramphotobackup;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class LiveActivity extends Activity {
    private ExoPlayer player;
    private PlayerView playerView;
    private TextView channelTitle;
    private final ArrayList<String> names = new ArrayList<>();
    private final ArrayList<String> urls = new ArrayList<>();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live);

        playerView = findViewById(R.id.playerView);
        channelTitle = findViewById(R.id.channelTitle);
        ListView list = findViewById(R.id.channelList);

        loadM3U();
        list.setAdapter(new ArrayAdapter<String>(
                this, android.R.layout.simple_list_item_1, names) {
            @Override public android.view.View getView(int position, android.view.View convertView,
                                                        android.view.ViewGroup parent) {
                TextView v = (TextView) super.getView(position, convertView, parent);
                v.setTextColor(0xFFFFFFFF);
                v.setTextSize(17);
                v.setPadding(18, 18, 18, 18);
                return v;
            }
        });

        list.setOnItemClickListener((parent, view, position, id) -> play(position));
    }

    private void loadM3U() {
        try (InputStream in = getResources().openRawResource(R.raw.channels);
             BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
            String line, pendingName = null;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.startsWith("#EXTINF:")) {
                    int comma = line.indexOf(',');
                    pendingName = comma >= 0 ? line.substring(comma + 1).trim() : "قناة";
                } else if (!line.isEmpty() && !line.startsWith("#") && pendingName != null) {
                    names.add(pendingName);
                    urls.add(line);
                    pendingName = null;
                }
            }
        } catch (Exception e) {
            channelTitle.setText("تعذر قراءة قائمة القنوات");
        }
    }

    private void play(int position) {
        if (position < 0 || position >= urls.size()) return;
        channelTitle.setText(names.get(position));
        if (player != null) player.release();

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.setMediaItem(MediaItem.fromUri(urls.get(position)));
        player.prepare();
        player.play();
    }

    @Override protected void onDestroy() {
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
